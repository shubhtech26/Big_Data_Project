install.packages('wordcloud')
install.packages('SnowballC')
install.packages('ggplot2')
install.packages('tidyverse')
install.packages('tidytext')
install.packages('reshape2')
install.packages('textdata')
install.packages('knitr')
library(tm) # text mining package
library(wordcloud) # word cloud generator
library(SnowballC) # text stemming
library(ggplot2) # graphs
library(tidyverse) # data manipulation
library(tidytext) # word lexicon dictionaries for sentiments
library(reshape2) # data transformation
library(textdata) # provides access to lexicon dictionaries
library(knitr)






getwd()
setwd("C:/Users/ADMIN/AppData/Local/Temp/Rtmp6Thuy1/downloaded_packages")
getwd()
gc()
install.packages('tm')
library('tm')
library('tm')
novel_v1 <- readLines("TarzanOfTheApes.txt")

Index_chapter1 <- which(novel_v1 == "Chapter I", arr.ind = TRUE)
Index_chapter2 <- which(novel_v1 == "Chapter II", arr.ind = TRUE)
Index_chapter3 <- which(novel_v1 == "Chapter III", arr.ind = TRUE)
Index_chapter4 <- which(novel_v1 == "Chapter IV", arr.ind = TRUE)
Index_chapter5 <- which(novel_v1 == "Chapter V", arr.ind = TRUE)
Index_chapter6 <- which(novel_v1 == "Chapter VI", arr.ind = TRUE)
Index_chapter7 <- which(novel_v1 == "Chapter VII", arr.ind = TRUE)
Index_chapter8 <- which(novel_v1 == "Chapter VIII", arr.ind = TRUE)
Index_chapter9 <- which(novel_v1 == "Chapter IX", arr.ind = TRUE)
Index_chapter10 <- which(novel_v1 == "Chapter X", arr.ind = TRUE)
Index_chapter11 <- which(novel_v1 == "Chapter XI", arr.ind = TRUE)
Index_chapter12 <- which(novel_v1 == "Chapter XII", arr.ind = TRUE)
Index_chapter13 <- which(novel_v1 == "Chapter XIII", arr.ind = TRUE)
Index_chapter14 <- which(novel_v1 == "Chapter XIV", arr.ind = TRUE)
Index_chapter15 <- which(novel_v1 == "Chapter XV", arr.ind = TRUE)
Index_chapter16 <- which(novel_v1 == "Chapter XVI", arr.ind = TRUE)



Chapter1 <- novel_v1[(Index_chapter1 + 1):(Index_chapter2 - 1)]
Chapter2 <- novel_v1[(Index_chapter2 + 1):(Index_chapter3 - 1)]
Chapter3 <- novel_v1[(Index_chapter3 + 1):(Index_chapter4 - 1)]
Chapter4 <- novel_v1[(Index_chapter4 + 1):(Index_chapter5 - 1)]
Chapter5 <- novel_v1[(Index_chapter5 + 1):(Index_chapter6 - 1)]
Chapter6 <- novel_v1[(Index_chapter6 + 1):(Index_chapter7 - 1)]
Chapter7 <- novel_v1[(Index_chapter7 + 1):(Index_chapter8 - 1)]
Chapter8 <- novel_v1[(Index_chapter8 + 1):(Index_chapter9 - 1)]
Chapter9 <- novel_v1[(Index_chapter9 + 1):(Index_chapter10 - 1)]
Chapter10 <- novel_v1[(Index_chapter10 + 1):(Index_chapter11 - 1)]
Chapter11 <- novel_v1[(Index_chapter11 + 1):(Index_chapter12 - 1)]
Chapter12 <- novel_v1[(Index_chapter12 + 1):(Index_chapter13 - 1)]
Chapter13 <- novel_v1[(Index_chapter13 + 1):(Index_chapter14 - 1)]
Chapter14 <- novel_v1[(Index_chapter14 + 1):(Index_chapter15 - 1)]
Chapter15 <- novel_v1[(Index_chapter15 + 1):(Index_chapter16 - 1)]







Chapter1


Chapter15



dir.create("chapters")
write.table(Chapter1, file = "chapters/Chapter1.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter2, file = "chapters/Chapter2.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter3, file = "chapters/Chapter3.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter4, file = "chapters/Chapter4.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter5, file = "chapters/Chapter5.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter6, file = "chapters/Chapter6.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter7, file = "chapters/Chapter7.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter8, file = "chapters/Chapter8.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter9, file = "chapters/Chapter9.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter10, file = "chapters/Chapter10.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter11, file = "chapters/Chapter11.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter12, file = "chapters/Chapter12.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter13, file = "chapters/Chapter13.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter14, file = "chapters/Chapter14.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(Chapter15, file = "chapters/Chapter15.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)



Novel_TOA <- VCorpus(DirSource("./chapters", ignore.case = TRUE, mode = "text"))
str(Novel_TOA)
Novel_TOA
inspect(Novel_TOA)
Extract_TEXT_TOA<- Novel_TOA[[1]]
Extract_TEXT_TOA
Extract_TEXT_TOA[1]


Novel_TOA_DTM<-DocumentTermMatrix(Novel_TOA)
Novel_TOA_DTM
inspect(Novel_TOA_DTM)
str(Novel_TOA_DTM)

TOA_TrmDOCMatrix<- TermDocumentMatrix(Novel_TOA)
TOA_TrmDOCMatrix
inspect(TOA_TrmDOCMatrix)

install.packages('dplyr')
install.packages('tidytext')
install.packages('ggplot2')

library(dplyr)
library(tidytext)
library(ggplot2)

Novel_tidy_TOA<-tidy(Novel_TOA)
Novel_tidy_TOA


Novel_TOA_words<-Novel_tidy_TOA %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_TOA_words

Novel_TOA_sentences<-Novel_tidy_TOA %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_TOA_sentences


Novel_tidy_Chap_1<-tidy(Novel_TOA[1])
Novel_tidy_Chap_1

Novel_Chap_1_words<-Novel_tidy_Chap_1 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap1_sentences<- Novel_tidy_Chap_1  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_1_words
Novel_Chap1_sentences


write.csv(Novel_Chap1_sentences, "output.csv", row.names = FALSE)

Novel_tidy_Chap_2<-tidy(Novel_TOA[8])
Novel_tidy_Chap_2

Novel_Chap_2_words<-Novel_tidy_Chap_2 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap2_sentences<- Novel_tidy_Chap_2  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_2_words
Novel_Chap2_sentences



Novel_tidy_Chap_3<-tidy(Novel_TOA[9])
Novel_tidy_Chap_3

Novel_Chap_3_words<-Novel_tidy_Chap_3 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap3_sentences<- Novel_tidy_Chap_3  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_3_words
Novel_Chap3_sentences


Novel_tidy_Chap_4<-tidy(Novel_TOA[10])
Novel_tidy_Chap_4

Novel_Chap_4_words<-Novel_tidy_Chap_4 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap4_sentences<- Novel_tidy_Chap_4  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_4_words
Novel_Chap4_sentences


Novel_tidy_Chap_5<-tidy(Novel_TOA[11])
Novel_tidy_Chap_5

Novel_Chap_5_words<-Novel_tidy_Chap_5 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap5_sentences<- Novel_tidy_Chap_5  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_5_words
Novel_Chap5_sentences


Novel_tidy_Chap_6<-tidy(Novel_TOA[12])
Novel_tidy_Chap_6

Novel_Chap_6_words<-Novel_tidy_Chap_6 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap6_sentences<- Novel_tidy_Chap_6  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_6_words
Novel_Chap6_sentences


Novel_tidy_Chap_7<-tidy(Novel_TOA[13])
Novel_tidy_Chap_7

Novel_Chap_7_words<-Novel_tidy_Chap_7 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap7_sentences<- Novel_tidy_Chap_7  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_7_words
Novel_Chap7_sentences


Novel_tidy_Chap_8<-tidy(Novel_TOA[14])
Novel_tidy_Chap_8

Novel_Chap_8_words<-Novel_tidy_Chap_8 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap8_sentences<- Novel_tidy_Chap_8  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_8_words
Novel_Chap8_sentences


Novel_tidy_Chap_9<-tidy(Novel_TOA[15])
Novel_tidy_Chap_9

Novel_Chap_9_words<-Novel_tidy_Chap_9 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap9_sentences<- Novel_tidy_Chap_9  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_9_words
Novel_Chap9_sentences



Novel_tidy_Chap_10<-tidy(Novel_TOA[2])
Novel_tidy_Chap_10

Novel_Chap_10_words<-Novel_tidy_Chap_10 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap10_sentences<- Novel_tidy_Chap_10  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_10_words
Novel_Chap10_sentences


Novel_tidy_Chap_11<-tidy(Novel_TOA[3])
Novel_tidy_Chap_11

Novel_Chap_11_words<-Novel_tidy_Chap_11 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap11_sentences<- Novel_tidy_Chap_11  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_11_words
Novel_Chap11_sentences


Novel_tidy_Chap_12<-tidy(Novel_TOA[4])
Novel_tidy_Chap_12

Novel_Chap_12_words<-Novel_tidy_Chap_12 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap12_sentences<- Novel_tidy_Chap_12  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_12_words
Novel_Chap12_sentences


Novel_tidy_Chap_13<-tidy(Novel_TOA[5])
Novel_tidy_Chap_13

Novel_Chap_13_words<-Novel_tidy_Chap_13 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap13_sentences<- Novel_tidy_Chap_13  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_13_words
Novel_Chap13_sentences


Novel_tidy_Chap_14<-tidy(Novel_TOA[6])
Novel_tidy_Chap_14

Novel_Chap_14_words<-Novel_tidy_Chap_14 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap14_sentences<- Novel_tidy_Chap_14  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_14_words
Novel_Chap14_sentences



Novel_tidy_Chap_15<-tidy(Novel_TOA[7])
Novel_tidy_Chap_15

Novel_Chap_15_words<-Novel_tidy_Chap_15 %>% unnest_tokens(word,text) %>% select(id,word) %>% mutate(word_length=nchar(word))%>% arrange(desc(word_length))
Novel_Chap15_sentences<- Novel_tidy_Chap_15  %>% unnest_tokens(sentence,text,token="regex",pattern="(?<!\\b\\p{L}r)\\.") %>% select(id,sentence) %>% mutate(sentence_length=nchar(sentence))%>% arrange(desc(sentence_length))
Novel_Chap_15_words
Novel_Chap15_sentences


Novel_TOA_v2 <- tm_map(Novel_TOA,content_transformer(gsub),pattern="'",replacement="") 
Novel_TOA_v2
Novel_remove_punct_num<-function(x) gsub("[^[:alpha:][:space:]]*","",x)
Novel_TOA_v3<-tm_map(Novel_TOA_v2,content_transformer(Novel_remove_punct_num))
Novel_TOA_v3[]
str(Novel_TOA_v3)
inspect(Novel_TOA_v3)


Novel_TOA_lowercaps<-tm_map(Novel_TOA_v3,content_transformer(tolower))
Novel_TOA_lowercaps
str(Novel_TOA_lowercaps)
inspect(Novel_TOA_lowercaps)



TOA_DocTrmMatrix<- DocumentTermMatrix(Novel_TOA_lowercaps)
TOA_DocTrmMatrix
str(TOA_DocTrmMatrix)
inspect(TOA_DocTrmMatrix)

Novel_TOA_dOC_trm_matrix<-as.matrix(TOA_DocTrmMatrix)

Novel_stopwords<-c(tm::stopwords("english"))
Novel_stopwords

Novel_rmstopwrds<-tm_map(Novel_TOA_lowercaps,removeWords,Novel_stopwords)
Novel_rmstopwrds
inspect(Novel_rmstopwrds[[1]])

Novel_stopwords_trmdocmatrix<-TermDocumentMatrix(Novel_rmstopwrds)
Novel_stopwords_trmdocmatrix

Novel_frequenttrms<-findFreqTerms(Novel_stopwords_trmdocmatrix,lowfreq = 5)
Novel_frequenttrms

length(Novel_frequenttrms)
Novel_frequenttrms[4]
nchar(Novel_frequenttrms[4])


freq_list<-list()
for(i in seq_along(Novel_rmstopwrds))
{
  freq_list[[i]]<-termFreq(Novel_rmstopwrds[[i]])
}
print(freq_list[[1]])

inspect(Novel_stopwords_trmdocmatrix)



Novel_dataframe<-as.data.frame(as.matrix(Novel_stopwords_trmdocmatrix))
Novel_dist<-dist(Novel_dataframe)
Novel_DG<-hclust(Novel_dist,method="ward.D2")
str(Novel_DG)


plot(Novel_DG)


Novel_stopwords_trmdocmatrix_rmsparse<-removeSparseTerms(Novel_stopwords_trmdocmatrix,0.4)
inspect(Novel_stopwords_trmdocmatrix_rmsparse)
Novel_rmsparsewords_dataframe<-as.data.frame(as.matrix(Novel_stopwords_trmdocmatrix_rmsparse))
Novel_rmSparse_dist<-dist(Novel_rmsparsewords_dataframe)
Novel_rmsparsematrix_graph<-hclust(Novel_rmSparse_dist,method="ward.D2")
plot(Novel_rmsparsematrix_graph)


Novel_stopwords_trmdocmatrix_rmsparse_0.2<-removeSparseTerms(Novel_stopwords_trmdocmatrix,0.2)
inspect(Novel_stopwords_trmdocmatrix_rmsparse_0.2)
Novel_rmsparsewords_dataframe_0.2<-as.data.frame(as.matrix(Novel_stopwords_trmdocmatrix_rmsparse_0.2))
Novel_rmSparse_dist_0.2<-dist(Novel_rmsparsewords_dataframe_0.2)
Novel_rmsparsematrix_graph_0.2<-hclust(Novel_rmSparse_dist_0.2,method="ward.D2")
plot(Novel_rmsparsematrix_graph_0.2)


freq_list_combined<-unlist(freq_list)
freq_list_summed<-tapply(freq_list_combined,names(freq_list_combined),sum)
words<-names(freq_list_summed)
words


pal<-brewer.pal(9,"BuGn")
str(pal)

TOAWC<-wordcloud(words,freq_list_summed,colors = pal[-(1:4)])
TOAWC<-wordcloud(words,freq_list_summed,min.freq=15,colors = pal[-(1:4)])

TOAWC<-wordcloud(words,freq_list_summed,min.freq=10,colors = pal[-(1:4)])

install.packages('syuzhet')
install.packages('quanteda')

library(quanteda)
library(syuzhet)
TOAtext<-Novel_TOA_v3[[1]]
TOAtext$content[1:15]


TOA_TOKENS<-lapply(Novel_TOA_v3,function(x) quanteda::tokens(x$content))
TOA_TOKENS



kwic(TOA_TOKENS[[7]],pattern="jungle")

kwic(TOA_TOKENS[[4]],pattern="The")


kwic(TOA_TOKENS[[8]],pattern="slowly")








TOA_DFM_Chap_1 <- quanteda::dfm(TOA_TOKENS[[1]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_2 <- quanteda::dfm(TOA_TOKENS[[2]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_3 <- quanteda::dfm(TOA_TOKENS[[3]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_4 <- quanteda::dfm(TOA_TOKENS[[4]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_5 <- quanteda::dfm(TOA_TOKENS[[5]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_6 <- quanteda::dfm(TOA_TOKENS[[6]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_7 <- quanteda::dfm(TOA_TOKENS[[7]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_8 <- quanteda::dfm(TOA_TOKENS[[8]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_9 <- quanteda::dfm(TOA_TOKENS[[9]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_10 <- quanteda::dfm(TOA_TOKENS[[10]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_11 <- quanteda::dfm(TOA_TOKENS[[11]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_12 <- quanteda::dfm(TOA_TOKENS[[12]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_13 <- quanteda::dfm(TOA_TOKENS[[13]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_14 <- quanteda::dfm(TOA_TOKENS[[14]]) %>% dfm_remove(Novel_stopwords)
TOA_DFM_Chap_15 <- quanteda::dfm(TOA_TOKENS[[15]]) %>% dfm_remove(Novel_stopwords)


TOA_DFM_CHap_1
str(TOA_DFM_Chap_1)



TOA_Doc_freq_Chap_1 <- quanteda::docfreq(TOA_DFM_Chap_1)
TOA_Doc_freq_Chap_2 <- quanteda::docfreq(TOA_DFM_Chap_2)
TOA_Doc_freq_Chap_3 <- quanteda::docfreq(TOA_DFM_Chap_3)
TOA_Doc_freq_Chap_4 <- quanteda::docfreq(TOA_DFM_Chap_4)
TOA_Doc_freq_Chap_5 <- quanteda::docfreq(TOA_DFM_Chap_5)
TOA_Doc_freq_Chap_6 <- quanteda::docfreq(TOA_DFM_Chap_6)
TOA_Doc_freq_Chap_7 <- quanteda::docfreq(TOA_DFM_Chap_7)
TOA_Doc_freq_Chap_8 <- quanteda::docfreq(TOA_DFM_Chap_8)
TOA_Doc_freq_Chap_9 <- quanteda::docfreq(TOA_DFM_Chap_9)
TOA_Doc_freq_Chap_10 <- quanteda::docfreq(TOA_DFM_Chap_10)
TOA_Doc_freq_Chap_11 <- quanteda::docfreq(TOA_DFM_Chap_11)
TOA_Doc_freq_Chap_12 <- quanteda::docfreq(TOA_DFM_Chap_12)
TOA_Doc_freq_Chap_13 <- quanteda::docfreq(TOA_DFM_Chap_13)
TOA_Doc_freq_Chap_14 <- quanteda::docfreq(TOA_DFM_Chap_14)
TOA_Doc_freq_Chap_15 <- quanteda::docfreq(TOA_DFM_Chap_15)

str(TOA_Doc_freq_Chap_1)

TOA_Doc_freq_Chap_1


TOA_Weights_Chap_1 <- quanteda::dfm_weight(TOA_DFM_Chap_1)
TOA_Weights_Chap_2 <- quanteda::dfm_weight(TOA_DFM_Chap_2)
TOA_Weights_Chap_3 <- quanteda::dfm_weight(TOA_DFM_Chap_3)
TOA_Weights_Chap_4 <- quanteda::dfm_weight(TOA_DFM_Chap_4)
TOA_Weights_Chap_5 <- quanteda::dfm_weight(TOA_DFM_Chap_5)
TOA_Weights_Chap_6 <- quanteda::dfm_weight(TOA_DFM_Chap_6)
TOA_Weights_Chap_7 <- quanteda::dfm_weight(TOA_DFM_Chap_7)
TOA_Weights_Chap_8 <- quanteda::dfm_weight(TOA_DFM_Chap_8)
TOA_Weights_Chap_9 <- quanteda::dfm_weight(TOA_DFM_Chap_9)
TOA_Weights_Chap_10 <- quanteda::dfm_weight(TOA_DFM_Chap_10)
TOA_Weights_Chap_11 <- quanteda::dfm_weight(TOA_DFM_Chap_11)
TOA_Weights_Chap_12 <- quanteda::dfm_weight(TOA_DFM_Chap_12)
TOA_Weights_Chap_13 <- quanteda::dfm_weight(TOA_DFM_Chap_13)
TOA_Weights_Chap_14 <- quanteda::dfm_weight(TOA_DFM_Chap_14)
TOA_Weights_Chap_15 <- quanteda::dfm_weight(TOA_DFM_Chap_15)

TOA_Weights_Chap_1
str(TOA_Weights_Chap_1)

TOA_Weights_Chap_2
str(TOA_Weights_Chap_2)



TOA_Tf_Idf_Chap_1 <- quanteda::dfm_tfidf(TOA_DFM_Chap_1, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_2 <- quanteda::dfm_tfidf(TOA_DFM_Chap_2, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_3 <- quanteda::dfm_tfidf(TOA_DFM_Chap_3, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_4 <- quanteda::dfm_tfidf(TOA_DFM_Chap_4, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_5 <- quanteda::dfm_tfidf(TOA_DFM_Chap_5, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_6 <- quanteda::dfm_tfidf(TOA_DFM_Chap_6, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_7 <- quanteda::dfm_tfidf(TOA_DFM_Chap_7, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_8 <- quanteda::dfm_tfidf(TOA_DFM_Chap_8, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_9 <- quanteda::dfm_tfidf(TOA_DFM_Chap_9, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_10 <- quanteda::dfm_tfidf(TOA_DFM_Chap_10, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_11 <- quanteda::dfm_tfidf(TOA_DFM_Chap_11, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_12 <- quanteda::dfm_tfidf(TOA_DFM_Chap_12, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_13 <- quanteda::dfm_tfidf(TOA_DFM_Chap_13, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_14 <- quanteda::dfm_tfidf(TOA_DFM_Chap_14, scheme_tf = "count", scheme_df = "inverse")
TOA_Tf_Idf_Chap_15 <- quanteda::dfm_tfidf(TOA_DFM_Chap_15, scheme_tf = "count", scheme_df = "inverse")

TOA_Tf_Idf_Chap_1
str(TOA_Tf_Idf_Chap_1)


install.packages("syuzhet")
library(syuzhet)

TOA_Text_CHap_1<-Novel_TOA_v3[[1]]
TOA_Text_CHap_1$content[1:15]

TOA_text_df<-as.data.frame(Novel_TOA_v3[[1]]$content)
TOA_text_df

TOA_as_String<-get_text_as_string("TarzanOfTheApes.txt")
TOA_as_String

TOA_SENTENCES <-get_sentences(TOA_as_String)
TOA_SENTENCES[1:15]

str(TOA_SENTENCES)


TOA_sentiments<-get_sentiment(TOA_SENTENCES,"syuzhet")
TOA_sentiments


TOAS_Bing<-get_sentiment(TOA_SENTENCES,"bing")
TOAS_Bing

TOAS_aFFIN<-get_sentiment(TOA_SENTENCES,"afinn")
TOAS_aFFIN

TOAS_Snrc<-get_sentiment(TOA_SENTENCES,"nrc")
TOAS_Snrc

TOAS_dictionary<-get_sentiment_dictionary()
TOAS_dictionary

TOAS_dictionary_BING<-get_sentiment_dictionary("bing")
TOAS_dictionary_BING

TOAS_Dictionary_Nrc<-get_sentiment_dictionary("nrc")
TOAS_Dictionary_Nrc

TOAS_Dictionary_afinn<-get_sentiment_dictionary("afinn")
TOAS_Dictionary_afinn


TOA_SUM<-sum(TOA_sentiments)
TOA_SUM

TOAS_Bing_SUM<-sum(TOAS_Bing)
TOAS_Bing_SUM

TOAS_aFFIN_Sum<-sum(TOAS_aFFIN)
TOAS_aFFIN_Sum

TOAS_nRC_SUM<-sum(TOAS_Snrc)
TOAS_nRC_SUM


summary(TOA_sentiments)
summary(TOAS_Bing)
summary(TOAS_aFFIN)
summary(TOAS_Snrc)


plot(TOA_sentiments,main="TarzanOfTheApes.txt",xlab="Narrative",ylab="Emotional Valence")

plot(TOAS_Bing,main="Sentimental Analysis for Tarzan OfThe Apes (Bing) ",xlab="Narrative",ylab="Emotional Valence")

plot(TOAS_aFFIN,main="Sentimental Analysis for Tarzan OfThe Apes (Affin )",xlab="Narrative",ylab="Emotional Valence")


plot(TOAS_Snrc ,main="Sentimental Analysis for Tarzan of the Apes (Nrc) ",xlab="Narrative",ylab="Emotional Valence")


TOAS_sentimentpctvalue<- get_percentage_values(TOA_sentiments,bins=10)
structure(TOAS_sentimentpctvalue)
plot(TOAS_sentimentpctvalue ,main="Tarzan of the Apes", xlab="Narrative",ylab="Emotional Valence",col="darkgreen")

TOAS_sentimentpctvalue<- get_percentage_values(TOA_sentiments,bins=50)
structure(TOAS_sentimentpctvalue)
plot(TOAS_sentimentpctvalue ,main="Tarzan of the Apes", xlab="Narrative",ylab="Emotional Valence",col="blue")

TOAS_sentimentpctvalue<- get_percentage_values(TOA_sentiments,bins=80)
structure(TOAS_sentimentpctvalue)
plot(TOAS_sentimentpctvalue ,main="Tarzan of the Apes", xlab="Narrative",ylab="Emotional Valence",col="red")



TOAS_Bing_pctvalue<- get_percentage_values(TOAS_Bing,bins=20)
structure(TOAS_Bing_pctvalue)
plot(TOAS_Bing_pctvalue ,main="Tarzan of the Apes Bing(PCT VALUE=20)", xlab="Narrative",ylab="Emotional Valence",col="purple")


TOAS_AFFIN_pctvalue<- get_percentage_values(TOAS_aFFIN,bins=30)
structure(TOAS_AFFIN_pctvalue)
plot(TOAS_AFFIN_pctvalue,main="Tarzan of the Apes  (PCT VALUE=30)", xlab="Narrative",ylab="Emotional Valence",col="blue")



TOAS_Snrc_pctvalue<- get_percentage_values(TOAS_Snrc,bins=50)
structure(TOAS_Snrc_pctvalue)
plot(TOAS_Snrc_pctvalue,main="Tarzan of the Apes nrc (PCT VALUE=50)", xlab="Narrative",ylab="Emotional Valence",col="orange")











