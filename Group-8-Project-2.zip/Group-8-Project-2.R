getwd()
setwd("C:/Users/ADMIN/AppData/Local/Temp/Rtmp6Thuy1/downloaded_packages")
getwd()
gc()
install.packages("sna")
install.packages("psych")
install.packages("factoextra")
install.packages("plotly")
install.packages("ggplot2")
install.packages("corrplot")
install.packages("lattice")

library(sna)
library(psych)
library(factoextra)
library(plotly)
library(ggplot2)
library(corrplot)

#read the table and print the features
Obesity_data<-read.csv("ObesityDataSet_raw_and_data_sinthetic.csv")
Obesity_data[1:10,]
Obesity_features <- colnames(Obesity_data)
Obesity_features
plot(Obesity_data)
#summary and describe
summary(Obesity_data)                                  
describe(Obesity_data)                                 


#encoding the dataset 
Obesity_data_num_v2<-Obesity_data

Obesity_data_num_v2$Gender <-ifelse(Obesity_data_num_v2$Gender == "Male", 1, 0)
Obesity_data_num_v2$FAVC<-ifelse(Obesity_data_num_v2$FAVC=="yes",1,0)
Obesity_data_num_v2$SMOKE<-ifelse(Obesity_data_num_v2$SMOKE=="yes",1,0)
Obesity_data_num_v2$SCC<-ifelse(Obesity_data_num_v2$SCC=="yes",1,0)
Obesity_data_num_v2$family_history_with_overweight<-ifelse(Obesity_data_num_v2$family_history_with_overweight=="yes",1,0)
Obesity_data_num_v2$CAEC <- ifelse(Obesity_data_num_v2$CAEC == "Always", 3,
                                   ifelse(Obesity_data_num_v2$CAEC == "Frequently", 2,
                                          ifelse(Obesity_data_num_v2$CAEC == "Sometimes", 1, 0)))
Obesity_data_num_v2$CALC <- ifelse(Obesity_data_num_v2$CALC == "Always", 3,
                                   ifelse(Obesity_data_num_v2$CALC == "Frequently", 2,
                                          ifelse(Obesity_data_num_v2$CALC == "Sometimes", 1, 0)))
Obesity_data_num_v2$NObeyesdad<-ifelse(Obesity_data_num_v2$NObeyesdad== "Obesity_Type_III", 7,
                                ifelse(Obesity_data_num_v2$NObeyesdad == "Obesity_Type_II", 6,
                                       ifelse(Obesity_data_num_v2$NObeyesdad == "Obesity_Type_I", 5,
                                              ifelse(Obesity_data_num_v2$NObeyesdad == "Overweight_Level_II", 4,
                                                ifelse(Obesity_data_num_v2$NObeyesdad == "Overweight_Level_I", 3,
                                                  ifelse(Obesity_data_num_v2$NObeyesdad == "Normal_Weight",2,1))))))
Obesity_data_num_v2$MTRANS<-ifelse(Obesity_data_num_v2$MTRANS=="Walking", 5,
                            ifelse(Obesity_data_num_v2$MTRANS=="Public_Trans", 4,
                                   ifelse(Obesity_data_num_v2$MTRANS=="Motorbike", 3,
                                          ifelse(Obesity_data_num_v2$MTRANS=="Bike", 2,1))))
      
Obesity_data_num_v2[1:10,]

summary(Obesity_data_num_v2)                                  
describe(Obesity_data_num_v2) 
plot(Obesity_data_num_v2)

Obesity_data <- Obesity_data %>%
  mutate_at(c(7,8,11,13,14), round)

Obesity_data$FCVC <- factor(Obesity_data$FCVC,
                          levels = c(1,2,3),
                          labels = c("Never", "Sometimes", "Always"))

Obesity_data$CH2O <- factor(Obesity_data$CH2O,
                          levels = c(1,2,3),
                          labels = c("Less than a liter", "Between 1-2L", "More"))

Obesity_data$FAF <- factor(Obesity_data$FAF,
                         levels = c(0,1,2,3),
                         labels = c("I do not have", "1 or 2 days", "2 or 4 days", "4 or 5 days"))

Obesity_data$TUE <- factor(Obesity_data$TUE,
                         levels = c(0,1,2),
                         labels = c("0–2 hours", "3–5 hours", "More than 5 hours"))

Obesity_data <- Obesity_data %>%
mutate_at(c(1,5,6,8,9,10,12,15,16,17), as.factor)

Obesity_Dataset_categorical <- melt(Obesity_data[,c(1,5:16)], id.vars = NULL)
Obesity_Dataset_numerical <- melt(Obesity_data[,c(2:4)], id.vars = NULL)
ggplot(data = Obesity_Dataset_categorical, aes(x = value)) + 
  facet_wrap(~variable, scales = "free", ncol = 4) + 
  geom_histogram(stat = "count", fill = "pink") + 
  theme(axis.text = element_text(size = 7),
        axis.title = element_text(size = 10),
        panel.background = element_rect(fill = "green"))



ggplot(data = Obesity_Dataset_numerical, aes(x = value)) + 
  facet_wrap(~variable, scales = "free", ncol = 4) + 
  geom_histogram(fill = "red") +
  theme(panel.background = element_rect(fill = "black"))



#scatter plot 
ggplot(Obesity_data, aes(x = Height, y = Weight, color = Gender)) +
  geom_point() +
  theme_minimal() +
  labs(title = "Scatter Plot of Weight vs Height grouping by Gender",
       x = "Height",
       y = "Weight") +
  scale_color_manual(values = c("pink", "red")) # Assign colors for Male and Female

ggplot(Obesity_data, aes(x = Age, y = Weight, color = Gender)) +
  geom_point() +
  theme_minimal() +
  labs(title = "Scatter Plot of Weight vs Height grouping by Gender",
       x = "Height",
       y = "Weight") +
  scale_color_manual(values = c("pink", "red")) # Assign colors for Male and Female

ggplot(Obesity_data, aes(x = Height, y = Weight, color = NObeyesdad)) +
  geom_point() +
  theme_minimal() +
  labs(title = "Scatter Plot of Weight vs Height grouping by NObeyesdad",
       x = "Height",
       y = "Weight") +
  scale_color_manual(values = c("pink", "red","yellow","orange","green","blue","cyan"))



ggplot(Obesity_data, aes(x = Age, y = Weight, color = NObeyesdad)) +
  geom_point() +
  theme_minimal() +
  labs(title = "Scatter Plot of Age vs Weight grouping by NObeyesdad",
       x = "Age",
       y = "Weight") +
  scale_color_manual(values = c("pink", "red","yellow","orange","green","blue","cyan"))


cor_obesity_data_visualization<-cor(Obesity_data_num_v2, use="complete.obs")
cor_obesity_data_visualization
corrplot(cor_obesity_data_visualization, method = "circle")



Obesity_dataset_Scal<- scale(Obesity_data_num_v2[,-16])
Obesity_dataset_Scal[1:10,]
Obesity_dataset_model_v3<-Obesity_dataset_Scal[,c(1:3,7,11,15,14)]
Obesity_dataset_model_v3

#lets copy selcted dataset into to
Obesity_dataset_v3_1<-Obesity_data_num_v2[,c(1:3,7,11,15,14)]
Obesity_dataset_v3_1

plot(Obesity_dataset_Scal)





Obesity_data.k2<-kmeans(Obesity_dataset_model_v3,centers = 2 )
Obesity_data.k2
str(Obesity_data.k2)

factoextra::fviz_cluster(Obesity_data.k2,Obesity_dataset_Scal)

Obesity_data.k3<-kmeans(Obesity_dataset_model_v3,centers = 3 )
Obesity_data.k3
factoextra::fviz_cluster(Obesity_data.k3,Obesity_dataset_Scal)



Obesity_data.k4<-kmeans(Obesity_dataset_model_v3,centers = 4 )
Obesity_data.k4
factoextra::fviz_cluster(Obesity_data.k4,Obesity_dataset_Scal)


Obesity_data.k5<-kmeans(Obesity_dataset_model_v3,centers = 5 )
Obesity_data.k5
factoextra::fviz_cluster(Obesity_data.k5,Obesity_dataset_Scal)

Obesity_data.k6<-kmeans(Obesity_dataset_model_v3,centers = 6 )
Obesity_data.k6
factoextra::fviz_cluster(Obesity_data.k6,Obesity_dataset_Scal)


Obesity_data.k7<-kmeans(Obesity_dataset_Scal,centers = 7 )
Obesity_data.k7
factoextra::fviz_cluster(Obesity_data.k7,Obesity_dataset_Scal)


Obesity_data.k8<-kmeans(Obesity_dataset_model_v3,centers = 8 )
Obesity_data.k8
factoextra::fviz_cluster(Obesity_data.k8,Obesity_dataset_Scal)


Obesity_data.k9<-kmeans(Obesity_dataset_model_v3,centers = 9 )
Obesity_data.k9
factoextra::fviz_cluster(Obesity_data.k9,Obesity_dataset_Scal)


Obesity_data.k10<-kmeans(Obesity_dataset_model_v3,centers = 10 )
Obesity_data.k10
factoextra::fviz_cluster(Obesity_data.k10,Obesity_dataset_Scal)

Obesity_data.k11<-kmeans(Obesity_dataset_model_v3,centers = 11 )
Obesity_data.k11
factoextra::fviz_cluster(Obesity_data.k11,Obesity_dataset_Scal)

Obesity_dataset_v3_1[1109,]
Obesity_dataset_v3_1[428,]



#ClusteringofWholeDataset 
Obesity_data.k2_whole<-kmeans(Obesity_data_num_v2,centers = 2 )
Obesity_data.k2_whole

factoextra::fviz_cluster(Obesity_data.k2_whole,Obesity_data_num_v2)

Obesity_data.k3_whole<-kmeans(Obesity_data_num_v2,centers = 3 )
Obesity_data.k3_whole
factoextra::fviz_cluster(Obesity_data.k3_whole,Obesity_data_num_v2)



Obesity_data.k4_whole<-kmeans(Obesity_data_num_v2,centers = 4 )
Obesity_data.k4_whole
factoextra::fviz_cluster(Obesity_data.k4_whole,Obesity_data_num_v2)


Obesity_data.k5_whole<-kmeans(Obesity_data_num_v2,centers = 5 )
Obesity_data.k5_whole
factoextra::fviz_cluster(Obesity_data.k5_whole,Obesity_data_num_v2)

Obesity_data.k6_whole<-kmeans(Obesity_data_num_v2,centers = 6 )
Obesity_data.k6_whole
factoextra::fviz_cluster(Obesity_data.k6_whole,Obesity_data_num_v2)


Obesity_data.k7_whole<-kmeans(Obesity_data_num_v2,centers = 7 )
Obesity_data.k7_whole
factoextra::fviz_cluster(Obesity_data.k7_whole,Obesity_data_num_v2)


Obesity_data.k8_whole<-kmeans(Obesity_data_num_v2,centers = 8 )
Obesity_data.k8_whole
factoextra::fviz_cluster(Obesity_data.k8_whole,Obesity_data_num_v2)


Obesity_data.k9_whole<-kmeans(Obesity_data_num_v2,centers = 9 )
Obesity_data.k9_whole
factoextra::fviz_cluster(Obesity_data.k9_whole,Obesity_data_num_v2)


Obesity_data.k10_whole<-kmeans(Obesity_data_num_v2,centers = 10 )
Obesity_data.k10_whole
factoextra::fviz_cluster(Obesity_data.k10_whole,Obesity_data_num_v2)

Obesity_data.k11_whole<-kmeans(Obesity_data_num_v2,centers = 11 )
Obesity_data.k11_whole
factoextra::fviz_cluster(Obesity_data.k11_whole,Obesity_data_num_v2)







#1205,1534
#SOME PART OF K MEANS IS LEFT

#WSS METHOD
wssplot <- function(data, nc=15, seed=1234){
  wss <- (nrow(data)-1)*sum(apply(data,2,var))
  for (i in 2:nc){
    set.seed(seed)
    wss[i] <- sum(kmeans(data, centers=i)$withinss)}
  plot(1:nc, wss, type="b", xlab="Number of Clusters",
       ylab="Within groups sum of squares")
  wss
}
wssplot(Obesity_dataset_v3_1,nc=12,seed=1234)

#FACTOEXTRA METHOD
factoextra::fviz_nbclust(Obesity_dataset_v3_1,FUNcluster = kmeans, method ="wss",k.max = 12,verbose = TRUE)



wssplot <- function(data, nc=15, seed=1234){
  wss <- (nrow(data)-1)*sum(apply(data,2,var))
  for (i in 2:nc){
    set.seed(seed)
    wss[i] <- sum(kmeans(data, centers=i)$withinss)}
  plot(1:nc, wss, type="b", xlab="Number of Clusters",
       ylab="Within groups sum of squares")
  wss
}
wssplot(Obesity_data_num_v2,nc=12,seed=1234)


factoextra::fviz_nbclust(Obesity_data_num_v2,FUNcluster = kmeans, method ="wss",k.max = 12,verbose = TRUE)











#trainingandtestingdataset70-30
Obesitydata_70_30<-Obesity_data_num_v2
Obesity_dataset_sumrow= nrow(Obesity_data_num_v2)
Obesity_dataset_sample=0.7
Obesity_rows_70_30= Obesity_dataset_sample * Obesity_dataset_sumrow
Obesity_rows_70_30
Obesitydata_train_70_30.index=sample(Obesity_dataset_sumrow,Obesity_rows_70_30)
length(Obesitydata_train_70_30.index)

Obesity_dataset_70_30.train = Obesitydata_70_30[Obesitydata_train_70_30.index,]
Obesity_dataset_70_30.train[1:20,]
Obesity_dataset_70_30.test = Obesitydata_70_30[-Obesitydata_train_70_30.index,]
Obesity_dataset_70_30.test[1:20,]


#trainingand testing 60-40
Obesitydata_60_40<-Obesity_data_num_v2
Obesity_dataset_sample=0.6
Obesity_rows_60_40= Obesity_dataset_sample * Obesity_dataset_sumrow
Obesity_rows_60_40
Obesitydata_train_60_40.index=sample(Obesity_dataset_sumrow,Obesity_rows_60_40)
length(Obesitydata_train_60_40.index)

Obesity_dataset_60_40.train = Obesitydata_60_40[Obesitydata_train_60_40.index,]
Obesity_dataset_60_40.train[1:20,]

Obesity_dataset_60_40.test = Obesitydata_60_40[-Obesitydata_train_60_40.index,]
Obesity_dataset_60_40.test[1:20,]



#trainingand testing 50-50
Obesitydata_50_50<-Obesity_data_num_v2
Obesity_dataset_sample=0.5
Obesity_rows_50_50= Obesity_dataset_sample * Obesity_dataset_sumrow
Obesity_rows_50_50
Obesitydata_train_50_50.index=sample(Obesity_dataset_sumrow,Obesity_rows_50_50)
length(Obesitydata_train_50_50.index)

Obesity_dataset_50_50.train = Obesitydata_50_50[Obesitydata_train_50_50.index,]
Obesity_dataset_50_50.train[1:20,]
Obesity_dataset_50_50.test = Obesitydata_50_50[-Obesitydata_train_50_50.index,]
Obesity_dataset_50_50.test[1:20,]


Obesity_featur_kmeans = c(1:3,7,11,15,14)

# Perform K-Means Clustering on the Training Sets
Obesity_data_kmeans_70 <- kmeans(Obesity_dataset_70_30.train[, Obesity_featur_kmeans], centers = 8) 
Obesity_data_kmeans_70
length(Obesity_data_kmeans_70)


Obesity_data_kmeans_60_40 <- kmeans(Obesity_dataset_60_40.train[,Obesity_featur_kmeans], centers = 8)
Obesity_data_kmeans_60_40

Obesity_data_kmeans_50_50 <- kmeans(Obesity_dataset_50_50.train[,Obesity_featur_kmeans], centers = 8)
Obesity_data_kmeans_50_50


# Perform K-NN Clustering on the Training Sets

install.packages("class")
library(class)
target = c("NObeyesdad")
Obesity_data_kNN_70<- knn(train = Obesity_dataset_70_30.train[,Obesity_featur_kmeans ], test = Obesity_dataset_70_30.test[,Obesity_featur_kmeans ], cl = Obesity_data_kmeans_70$cluster, k = 8)
Obesity_data_kNN_70


Obesity_data_kNN_60<- knn(train = Obesity_dataset_60_40.train[,Obesity_featur_kmeans ], test = Obesity_dataset_60_40.test[, Obesity_featur_kmeans], cl = Obesity_data_kmeans_60_40$cluster, k = 8)
Obesity_data_kNN_60

Obesity_data_kNN_50<- knn(train = Obesity_dataset_50_50.train[,Obesity_featur_kmeans ], test = Obesity_dataset_50_50.test[, Obesity_featur_kmeans], cl = Obesity_data_kmeans_50_50$cluster, k = 8)
Obesity_data_kNN_50



# Perform K-Means Clustering on the Test Sets

Obesity_data_kmeans_70_test <- kmeans(Obesity_dataset_70_30.test[, Obesity_featur_kmeans], centers = 8) 
Obesity_data_kmeans_70_test

Obesity_data_kmeans_60_40_test <- kmeans(Obesity_dataset_60_40.test[,Obesity_featur_kmeans], centers = 8)
Obesity_data_kmeans_60_40_test

Obesity_data_kmeans_50_50_test <- kmeans(Obesity_dataset_50_50.test[,Obesity_featur_kmeans], centers = 8)
Obesity_data_kmeans_50_50_test




Obesitydata__knnkmeanscomparison_70 <- table(Obesity_data_kNN_70,Obesity_data_kmeans_70_test$cluster)
Obesitydata__knnkmeanscomparison_70

Obesitydata__knnkmeanscomparison_60 <- table(Obesity_data_kNN_60,Obesity_data_kmeans_60_40_test$cluster)
Obesitydata__knnkmeanscomparison_60

Obesitydata__knnkmeanscomparison_50 <- table(Obesity_data_kNN_50,Obesity_data_kmeans_50_50_test$cluster)
Obesitydata__knnkmeanscomparison_50



nrow(Obesity_dataset_70_30.test)

Obesity_dataset_70_30.glm = glm(NObeyesdad ~ Gender + Age + Height + FCVC + CALC + CH2O + TUE, family = gaussian, data = Obesity_dataset_70_30.train)
summary(Obesity_dataset_70_30.glm)
Obesity_dataset_70_30.glm_anova = anova(Obesity_dataset_70_30.glm, test="Chisq")
Obesity_dataset_70_30.glm_anova


Obesity_dataset_60_40_glm = glm(NObeyesdad ~ Gender + Age + Height + FCVC + CALC + CH2O + TUE, family = gaussian, data = Obesity_dataset_60_40.train)
summary(Obesity_dataset_60_40_glm)
Obesity_dataset_60_40_glm_anova=anova(Obesity_dataset_60_40_glm,test="Chisq")
Obesity_dataset_60_40_glm_anova


Obesity_dataset_50_50_glm = glm(NObeyesdad ~ Gender + Age + Height + FCVC + CALC + CH2O + TUE, family = gaussian, data = Obesity_dataset_50_50.train)
summary(Obesity_dataset_50_50_glm)

Obesity_dataset_50_50_glm_anova=anova(Obesity_dataset_50_50_glm,test="Chisq")
Obesity_dataset_50_50_glm_anova

plot(Obesity_dataset_70_30.glm)







#Prediction 


Obesity_Data_test70_30_prediction = predict(Obesity_dataset_70_30.glm, newdata= Obesity_dataset_70_30.test)
summary(Obesity_Data_test70_30_prediction)
Obesity_Data_test70_30_prediction

Obesity_Data_test60_40_prediction = predict(Obesity_dataset_60_40_glm, newdata= Obesity_dataset_60_40.test)
summary(Obesity_Data_test60_40_prediction)
Obesity_Data_test60_40_prediction


Obesity_Data_test50_50_prediction = predict(Obesity_dataset_50_50_glm, newdata= Obesity_dataset_50_50.test)
summary(Obesity_Data_test50_50_prediction)
Obesity_Data_test50_50_prediction

#Confidence interval

confint(Obesity_dataset_70_30.glm)
confint(Obesity_dataset_60_40_glm)
confint(Obesity_dataset_50_50_glm)




# k means

Obesity_Data_test70_30_prediction_k8 = kmeans(Obesity_Data_test70_30_prediction, centers=8)
Obesity_Data_test_60_40_prediction_k8 = kmeans(Obesity_Data_test60_40_prediction, centers=8)
Obesity_Data_test_50_50_prediction_k8= kmeans(Obesity_Data_test50_50_prediction, centers=8)





install.packages("crosstable")
library(crosstable)

install.packages("gmodels")
library(gmodels)




length(Obesity_Data_test70_30_prediction_k8)
length(Obesity_data_kmeans_70_test)



Obesity_Data_test_70_30_crosstable= CrossTable(Obesity_Data_test70_30_prediction_k8$cluster , Obesity_data_kmeans_70_test$cluster,prop.chisq=TRUE)
Obesity_Data_test_60_40_crosstable= CrossTable(Obesity_Data_test_60_40_prediction_k8$cluster ,Obesity_data_kmeans_60_40_test$cluster,prop.chisq=TRUE)
Obesity_Data_test_50_50_crosstable= CrossTable(Obesity_Data_test_50_50_prediction_k8$cluster , Obesity_data_kmeans_50_50_test$cluster,prop.chisq=TRUE)

testSet70.pred.k8$cluster
kmeans_test_70$cluster
length(testSet70.pred.k8$cluster)
length(kmeans_test_70$cluster)



plot(Obesity_dataset_70_30.test$NObeyesdad, Obesity_Data_test70_30_prediction, main = "Actual Outcome vs Predicted Outcome NObeyesdad (70%-30%)",
     xlab = "Actual outcome", ylab = "Predicted outcome", pch = 19)



plot(Obesity_dataset_60_40.test$NObeyesdad, Obesity_Data_test60_40_prediction, main = "Actual Outcome vs Predicted Outcome NObeyesdad (60%-40%)",
     xlab = "Actual outcome", ylab = "Predicted outcome", pch = 19)


plot(Obesity_dataset_50_50.test$NObeyesdad,Obesity_Data_test50_50_prediction , main = "Actual Outcome vs Predicted Outcome NObeyesdad( 50%-50%)",
     xlab = "Actual outcome", ylab = "Predicted outcome", pch = 19)


Obesity_data_70_30_confusion_matrix <- Obesity_Data_test_70_30_crosstable$t
Obesity_data_70_30_confusion_matrix

Obesity_data_60_40_confusion_matrix <- Obesity_Data_test_60_40_crosstable$t
Obesity_data_60_40_confusion_matrix

Obesity_data_50_50_confusion_matrix <- Obesity_Data_test_50_50_crosstable$t
Obesity_data_50_50_confusion_matrix
accuracy <- sum(diag(Obesity_data_50_50_confusion_matrix)) / sum(Obesity_data_50_50_confusion_matrix)

precision <- diag(Obesity_data_50_50_confusion_matrix) / colSums(Obesity_data_50_50_confusion_matrix)
recall <- diag(Obesity_data_50_50_confusion_matrix) / rowSums(Obesity_data_50_50_confusion_matrix)
specificity <- sapply(1:nrow(Obesity_data_50_50_confusion_matrix), function(i) {
  TN <- sum(Obesity_data_50_50_confusion_matrix[-i, -i])
  FP <- sum(Obesity_data_50_50_confusion_matrix[-i, i])
  TN / (TN + FP)
})
error <- 1 - accuracy
error
precision
error
specificity
recall






